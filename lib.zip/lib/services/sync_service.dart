import 'dart:convert';
import 'package:http/http.dart' as http;

class SyncService {
  // ------------------------------------
  // 1. CREDENTIALS & IDs
  // ------------------------------------
  static const String metaCatalogId = 'YOUR_CATALOG_ID';
  static const String metaAccessToken = 'YOUR_META_TOKEN';

  // ------------------------------------
  // 2. THE INSTANT META UPDATE FUNCTION
  // ------------------------------------
  Future<bool> updateStockInMeta(String retailerId, bool isAvailable) async {
    // Meta's Batch Endpoint (v19.0 or latest)
    final String url = 'https://graph.facebook.com/v19.0/$metaCatalogId/items_batch';
    final String newStatus = isAvailable ? 'in stock' : 'out of stock';

    // Construct the payload using the 'id' column value from your sheet (retailer_id)
    final payload = {
      "requests": [
        {
          "method": "UPDATE",
          "retailer_id": retailerId,
          "data": { "availability": newStatus }
        }
      ]
    };

    try {
      print("Sending instant Meta stock update for $retailerId to: $newStatus...");
      
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $metaAccessToken',
        },
        body: jsonEncode(payload),
      );
      
      if (response.statusCode == 200) {
        print("✅ Meta Catalog updated successfully!");
        return true;
      } else {
        print("❌ Meta API Error: ${response.body}");
        return false;
      }
    } catch (e) {
      print("⚠️ Network Error updating Meta: $e");
      return false;
    }
  }
}